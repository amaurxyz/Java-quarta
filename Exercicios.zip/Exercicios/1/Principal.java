import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int max=10;

        String vet[] = new String[max];

        for (int i = 0; i<max; i++){
            System.out.print("Digite o nome "+ (i+1) + ": ");
            vet[i] = sc.nextLine();
        }

        System.out.println("\n");

        for (int i = 0; i<max; i++){
            System.out.print("Nome " + (i+1) + ": " + vet[i] + "\n");
        }
        sc.close();
    }
}