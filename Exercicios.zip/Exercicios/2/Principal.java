import java.time.LocalDate;
import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int max=10;
        
        LocalDate dataAtual = LocalDate.now();
        int anoAtual = dataAtual.getYear();

        String filme[] = new String[max];
        int ano[] = new int[max];
        String diretor[] = new String[max];

        for (int i = 0; i<max; i++){
            boolean ver = false;
            System.out.print("Digite o filme "+ (i+1) + ": ");
            filme[i] = sc.nextLine();

            while (ver == false){
                System.out.print("Digite o ano do filme "+ (i+1) + ": ");
                ano[i] = sc.nextInt();
                sc.nextLine();
                if (ano[i] <= anoAtual){
                    ver = true;
                }
                else{
                    System.out.println("Digite um ano válido");
                }
            }

            System.out.print("Digite o diretor do filme "+ (i+1) + ": ");
            diretor[i] = sc.nextLine();     

            System.out.print("\n");
        }

        System.out.println("\n");

        for (int i = 0; i<max; i++){
            System.out.print(filme[i] + "\nData de Lançamento: " + ano[i] + "\nNome do Diretor: " + diretor[i] + "\n \n" );
        }
        sc.close();
    }
}